import { JSX } from "react";
import { Outlet } from "react-router-dom";
import { BasicHeader } from "./header/BasicHeader";
import useEvent from "../hooks/useEvent";

const BasicLayout = ():JSX.Element => {
  const { isMainFullpage } = useEvent();


  return(
    <div>
      {/* 헤더 */}
      <header className={isMainFullpage ? "absolute":""}>
        <BasicHeader/>
      </header>
      <div className="main-content">
        <div className="main-wrapper">
          <Outlet/>
        </div>
      </div>
    </div>
  )
}
export default BasicLayout;