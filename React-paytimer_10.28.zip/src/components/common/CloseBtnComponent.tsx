import React, { JSX } from "react";

type CloseBtnTypes = {
  children : React.ReactElement<CloseBtnTypes>;
}

export default function CloseBtnComponent({children} : CloseBtnTypes):JSX.Element{
  return(
    <>
      
    </>
  )
}