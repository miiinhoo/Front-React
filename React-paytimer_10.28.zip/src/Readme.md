- 필수 설치목록

- NPM
npm i

- FireBase Tool
npm i -g firebase-tools

- FullPage
npm i -g fullPage

- SASS
npm i sass

- RRD
npm i react-router-dom



- 번외 ㄱ

- Firebase로그인 기능
firebase login

- functions 폴더로 이동
cd functions

- firebase admin 설치
npm install firebase-admin express cors