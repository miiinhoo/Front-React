
export const FormDataArrays = [
  {
    addPage: {
      title: "",       // 종류 (dropdown)
      amount: 0,      // 수량
      payDate: "",     // 날짜
      method: "",      // 결제방법
      cycle: "",   // 개월수 (기본값)
      memo: "",        // 요금제
    },
  } as const,
];

export type PaymentData = typeof FormDataArrays[0]["addPage"];