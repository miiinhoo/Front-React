export const SectionTitleArray = [
  { id:1, name:"PAY",delay:"0"},
  { id:2, name:"TIME",delay:"0.35"}
]