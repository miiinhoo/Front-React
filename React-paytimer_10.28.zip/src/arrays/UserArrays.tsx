export const UserArrays = [
    { id: 1, text: "이름", name:"name"},
    { id: 2, text: "아이디",name: "email" },
    { id: 3, text: "비밀번호", name: "password" },
    { id: 4, text: "비밀번호 확인", name: "passwordcheck"},
  ];
