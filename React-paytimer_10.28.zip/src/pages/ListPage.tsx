
import { JSX } from "react";
import { AddPageArrays } from "../arrays/AddPageArrays";
import ButtonComponent from "../components/common/ButtonComponent";
import useEvent from "../hooks/useEvent";

function ListPage():JSX.Element{
  const { 
    bool:openModal,
    setBool:setOpenModal,

  } = useEvent();
  return(
    <div className="page-wrapper">
      <div className="page-inner">
        <div className="page-content">
          <h2>결제일 관리 리스트</h2>
          <div className="table-content">
            <table>
              <thead>
                <tr>
                  {
                  AddPageArrays.map(data => (
                    <th key={data.id}>
                      {data.text}
                    </th>
                  ))
                  }
                </tr>
              </thead>
              <ButtonComponent
              text="검색"
              click={() => setOpenModal(true)}
              openModal={openModal}
              />
              
            </table>
          </div>

        </div>
      </div>
    </div>
  )
}
export default ListPage;
