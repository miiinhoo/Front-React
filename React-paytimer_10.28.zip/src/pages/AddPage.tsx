import { JSX, useState } from "react";
import { AddPageArrays } from "../arrays/AddPageArrays";
import SelectComponent from "../components/common/SelectComponent";
import { getPayments, createPayment } from "../api/AddPageAPI";
import useEvent from "../hooks/useEvent";
import useFireBase from "../hooks/useFireBase";
import ButtonComponent from "../components/common/ButtonComponent";
import { FormDataArrays } from "../arrays/FormDataArrays";

// useFireBase.tsx
const api = {
  get : getPayments,
  create : createPayment
}

function AddPage(): JSX.Element {
  const { 
    // 구조 분해 할당
    temp:add,
    bool:openOption,
    setBool:setOpenOption,
    option: changedMyOption,
    setOption: setChangedMyOption,
    handleChange,
    doNotRefreshSite
  } = useEvent();

  const {
    formData,
    setFormData,
    createData
  } = useFireBase({
    initFormData: FormDataArrays[0].addPage,
    api
  })
  
  const [ selectedItem, setSelectedItem ] = useState<string | "선택하세요..">("선택하세요..");
  const [ putItem, setPutItem ] = useState<string | "">("");

  const dropdownList = AddPageArrays.find(item => item.type === "dropdown");

  const selectedInner = dropdownList?.outerSelect?.find(out => out.name === selectedItem)?.innerSelect || [];

  return (
    <div className="page-wrapper">
      <div className="page-inner">
        <div className="page-content">
          <form>
            <h2>등록페이지</h2>
            {
              AddPageArrays.map(list => (
                <label key={list.id}>
                  {list.type === "dropdown" ? (
                    <>
                      <div className="outerSelectItem" onClick={() => setOpenOption(prev => !prev)}>
                        <div className="selectLists">
                          {/* 현재 선택된 텍스트 */}
                          <p className="selectedText">{putItem === "" ? selectedItem : putItem}</p>

                          {/* 드롭다운 옵션 */}
                          {openOption && list.outerSelect?.map((temp,inx) => (
                            <p 
                              key={inx}
                              onClick={(e) => {
                                doNotRefreshSite(e);
                                setSelectedItem(temp.name); // 선택한 텍스트 저장
                                setPutItem("");
                                setOpenOption(false);
                              }}
                            >
                              {temp.name}
                            </p>
                          ))}
                        </div>
                      </div>
                    </>
                  ) : list.type === "select" ? (
                    <SelectComponent handleChange={(e) => {
                      setFormData({
                        ...formData,
                        [e.target.name]:e.target.value
                      })
                    }} add={formData} list={list}>
                      {list.options?.map((opt,inx) => (
                        <option key={inx} value={opt}>{opt}</option>
                      ))}
                    </SelectComponent>
                  ) : (
                    <input
                      type={list.type ?? "text"}
                      value={add[list.name] || ""}
                      name={list.name}
                      placeholder={list.text}
                      onChange={(e:React.ChangeEvent<HTMLInputElement>) => {
                        
                        setFormData({
                          ...formData,
                          [e.target.name] : e.target.value
                        })
                      }}
                    />
                  )}
                </label>
              ))
            }
            
                {  selectedInner.length > 0 && (
                      <div className="InnerBox-wrapper">
                          { !openOption &&
                            selectedInner.map((list,inx) => (
                              <button type="button" className="InnerBox-Items" key={inx}
                              onClick={(e) => {
                                doNotRefreshSite(e);
                                setPutItem(list.name);
                                const fullField = `${selectedItem} / ${list.name}`;
                                setFormData(prev => ({
                                  ...prev,
                                  title:fullField
                                }))
                              }}
                              >
                                <span className="InnerBox-Image">
                                  <img src={list.img} alt={list.name} />
                                </span>
                                <span className="InnerBox-text">
                                  {list.name}
                                </span>
                              </button>
                            ))
                          }
                      </div>
          )}
          
          <ButtonComponent 
          types="submit"
          text="등록"
          click={(e) => {
              doNotRefreshSite(e);
              createData({...formData});
          }}
          />
          </form>
        </div>
      </div>
    </div>
  );
}

export default AddPage;
