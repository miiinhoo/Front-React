import { useEffect } from "react";
import { addComment, getComments } from "../../api/FirebaseAPI";
import { Comment } from "../../arrays/CommentArrays";
import { initFormData } from "../../arrays/InitFormArray";
import useFirebase from "../../hooks/useFirebase";

const api = {
    get: getComments,
    add: addComment,
}

export default function CommentPage(){
    const { formData,comments,tryGet,tryAdd,handleChange } = useFirebase({
        initFormData:() => initFormData.commentPage,
        api,
    })
    useEffect(() => {
        tryGet()
    },[])
    return(
        <div className="main-content page">
            {
                comments.length > 0 ?
                <div className="comment-wrapper">
                    {comments.map((list,inx) => (
                        <p className="comment-content" key={inx}>
                            <span>
                                {list.userId}
                            </span>
                            <p>
                                {list.comment}
                            </p>
                        </p>
                    ))}
                </div>
                :
                <p>
                    데이터가 없네요.
                </p>
            }
            <form action="">
                {Comment.map(i => (
                    <label key={i.id}>
                        {i.type === "textarea" ?
                        <textarea
                        placeholder={i.text}
                        name={i.name}
                        value={formData[i.name] || ""}
                        onChange={handleChange}>
                        </textarea>
                        :
                        <input type={i.type} 
                        name={i.name}
                        placeholder={i.text}
                        value={formData[i.name] || ""}
                        onChange={handleChange}/>
                        }
                    </label>
                ))}
                <button type="button" onClick={() => tryAdd(null)}>
                    댓글작성
                </button>
            </form>
        </div>
    )
}