export default function ContactPage(){
    return(
        <div>
            ContactPage입니다.
        </div>
    )
}