export default function Footer(){
    return(
        <>푸터</>
    )
}