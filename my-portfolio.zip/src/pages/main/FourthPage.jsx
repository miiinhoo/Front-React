export default function FourthPage(){
    return(
        <section>
            <div className="page-inner">
                네번째 페이지
            </div>
        </section>
        
    )
}