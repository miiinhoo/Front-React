export default function SecondPage(){
    return(
        <section>
            <div className="page-inner">
                두번째 페이지
                ///
                <br />
                나의 SKILL들 나열
            </div>
        </section>
        
    )
}