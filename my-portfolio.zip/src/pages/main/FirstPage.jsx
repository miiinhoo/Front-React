export default function FirstPage(){
    return(
        <section>
            <div className="page-inner">
                첫번째 페이지
                /// 
                <br />
                꾸미기 요소 추가 / or 큰 글씨 ( 100px 이상 최소 8rem )
                좌측 중앙 정렬 배치
            </div>
        </section>
        
    )
}