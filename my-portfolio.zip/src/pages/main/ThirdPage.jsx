import SwiperPage from "./SwiperPage";

export default function ThirdPage(){
    return(
        <section>
            <div className="page-inner">
                Swiper-Slide
                <SwiperPage/>
            </div>
        </section>
        
    )
}