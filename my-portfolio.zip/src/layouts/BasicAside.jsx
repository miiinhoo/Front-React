export default function BasicAside(){
    return(
        <div className="main-aside">
            오른쪽 스티키
        </div>
    )
}