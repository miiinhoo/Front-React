
import { db } from "../firebase";                                    
import { 
  collection, addDoc, getDocs, query, orderBy, deleteDoc, doc,
  serverTimestamp 
} from "firebase/firestore";                                        

export const addComment = async (data) => {                         

  const payload = {                                               
    userId: data.userId,                                            
    comment: data.comment,                                           
    passwordHash: data.passwordHash,                                  
    createdAt: serverTimestamp(),                                   
    uid: data.uid ?? null,                                      
  };
  return await addDoc(collection(db, "comments"), payload);       
};


export const getComments = async () => {                            
  const q = query(                                                    
    collection(db, "comments"),
    orderBy("createdAt", "desc")
  );
  const snap = await getDocs(q);                                    
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));          
};


export const deleteCommentById = async (id) => {                   
  await deleteDoc(doc(db, "comments", id));                          
};
