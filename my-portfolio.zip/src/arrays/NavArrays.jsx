export const Nav = [
    {
        id: 1, text: "Intro",path:"/"
    },
    {
        id: 2, text: "Contact",path:"contact"
    },
    {
        id: 3, text: "Comment",path:"comment"
    },
    {
        id: 4, text: "Github", path:"https://github.com/miiinhoo"
    }
]