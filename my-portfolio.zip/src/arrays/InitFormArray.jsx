export const initFormData = {
    commentPage:{
        userId: "",
        password: "",
        comment: "",
    }
}