import './Modal.css';
import CloseBtnComponent from './CloseBtnComponent';

const ModalComponent = ({bool,setBool}) => {

    return(
        <div className={"modal"+ (bool ? " show":"")}>
            <CloseBtnComponent setBool={setBool}/>
        </div>
    )
}
export default ModalComponent;