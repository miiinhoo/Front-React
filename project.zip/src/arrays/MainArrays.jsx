export const OrderList = [
    { id: 1, name: "상품리스트",path:'itemlist'},
    { id: 2, name: "판매거래처",path:'customer'},
    { id: 3, name: "주문완료현황",path:"orderreceive"}
  ];

  export const BuyerList = [
    {id: 1, name: "부품리스트", path:'partlist'},
    {id: 2, name:"구매거래처",path:'buyercustomer'}
  ]
  export const NavBar = [
    { 
      id: 1, name:"ORDER", path:'/itemlist'
    },
    {
      id: 2, name:"BUYER",path:'/buyer'
    },
    {
      id: 3, name:"PLAN",path:'/plan'
    },
    {
      id: 4, name:"STOCK",path:'/stock'
    }
  ];

  export const TestAdmin = {
    "ID":"admin",
    "Password":"1234"
  }



 
