const WoodenMainPage = () => {
    return(
        <div className="gridbox">
            <div className="grid">1</div>
            <div className="grid">2</div>
            <div className="grid">3</div>
            <div className="grid">4</div>
        </div>
    )
};
export default WoodenMainPage;