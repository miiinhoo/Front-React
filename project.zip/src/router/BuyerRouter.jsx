// Buyer라우터
import { lazy, Suspense } from 'react';
import { Navigate } from 'react-router-dom';

const PartOrder = lazy(() => import('../pages/part/PartOrder'));
const BuyerCustomer = lazy(() => import('../pages/part/BuyerCustomer'))

const Loading = <div>Loading...</div>
const BuyerRouter = [
    {
        path:'buyer',
        element:<Suspense><Navigate replace to = "/partlist"/></Suspense>
    }, 
    {
        path:'partlist',
        element: <Suspense fallback={Loading}><PartOrder/></Suspense>
    },
    {
        path:'buyercustomer',
        element: <Suspense fallback={Loading}><BuyerCustomer/></Suspense>
    }
];
export default BuyerRouter;