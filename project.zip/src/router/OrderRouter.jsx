//< Order라우터 >
import { lazy, Suspense } from "react";

const ItemList = lazy(() => import("../pages/customer/ItemList"));
const CustomerList = lazy(() => import("../pages/customer/CustomerList"));
const OrderApprovePage = lazy(() => import("../pages/customer/OrderApprovePage"));

const Loading = <div>Loading...</div>;

const OrderRouter = [
  {
    path: "itemlist",
    element: <Suspense fallback={Loading}><ItemList /></Suspense>,
  },
  {
    path: "customer",
    element: <Suspense fallback={Loading}><CustomerList /></Suspense>,
  },
  {
    path: "orderreceive",
    element: <Suspense fallback={Loading}><OrderApprovePage/></Suspense>
  }
];

export default OrderRouter;
