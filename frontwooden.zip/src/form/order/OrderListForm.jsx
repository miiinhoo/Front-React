
import { useEffect } from "react";
import { OrderListArr } from "../../arrays/OrderListArrays";
import axios from "axios";
import { useCRUD } from "../../hook/useCRUD";
import ButtonComponent from "../../components/ButtonComponent";


const OrderListForm = ({ formData, onChange }) => {
 
   const {
    customer,
    itemList,
    setCustomer,
    setItemList,
    customerId,
    itemListId,
    setCustomerId,
    setItemListId,
    orderQty,
    setOrderQty,
   } = useCRUD();

  useEffect(()=> {
    axios.get("/api/sellercustomer").then(res => {
      const options = res.data.map(temp => ({ label: temp.cusComp, value: temp.cusNo}));
      setCustomer(options);
    });
    axios.get("/api/itemlist").then(res => {
      const options = res.data(items => ({ label: items.itemName, value: items.itemNo}));
      setItemList(options);
    })
  },[])

  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.post("/api/order/orderlist",{
      customerId,
      itemListId,
      orderQty,
    });
    alert("주문완료");
  }


  return (
    <div className="form-wrapper">
      <form onSubmit={onSubmit}>
        <label>거래처</label>
        <select onChange={(e) => setCustomerId(Number(e.target.value))} required>
          { customer.map(option => (
            <option key={option.value} value={option.value}>{option.label}</option>
          ))};
        </select>
        <label>상품</label>
        <select onChange={(e) => setItemListId(Number(e.target.value))} required>
          { itemList.map(option => (
            <option key={option.value} value={option.value}>{option.label}</option>
          ))}
        </select>
        <label>수량</label>
        <input type="number" min="1" value={orderQty} onChange={e => setOrderQty(Number(e.target.value))} required/>
        {
          OrderListArr.map(data => (
            <p>
              <span className="form-child">{data.content}</span>
            </p>
          ))
        }

        <ButtonComponent type={"submit"} text={"저장"}/>
      </form>
      {OrderListArr.slice(1).map((data, idx) => (
        <div className="form-content" key={idx}>
          <p>
            <span className="form-child">{data.content}</span>
            <input
              type={data.input}
              name={data.clmn}
              value={formData[data.clmn] || ""}
              onChange={onChange}
            />
            
          </p>
        </div>
      ))}
      
    </div>
  );
};

export default OrderListForm;
