export const sellCustomerArray = [            
  { id: 1, clmn: "cusNo", input: "number",content: "판매처 번호" },
  { id: 2, clmn: "cusComp", input: "text", content: "판매처명" },
  { id: 3, clmn: "cusName", input: "text", content: "담당자" },
  { id: 4, clmn: "cusEmail", input: "text", content: "이메일" },
  { id: 5, clmn: "cusPhone", input: "text", content: "판매처 전화번호" },
  { id: 6, clmn: "cusAddr", input: "text", content: "판매처주소" },
];