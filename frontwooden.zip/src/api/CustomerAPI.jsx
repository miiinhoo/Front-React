import axios from "axios";
import { BASE_URL } from "./PartOrderAPI";

const host = BASE_URL;

// 전체 주문 조회
export const getCustomer = async () => {
    const res = await axios.get(`${host}/order/sellercustomer`);
    // console.log("API 응답:", response.data);
    return res.data;
};



export const createCustomer = async (formData) => {
  const res = await axios.post(`${host}/order/sellercustomer`, formData, {
    headers: {
      'Content-Type': 'application/json',
    },
  });
  return res.data;
};

// 단건 수정
export const updateCustomer = async (formData) => {
  const res = await axios.put(`${host}/order/sellercustomer`, formData, {
    headers: { 'Content-Type': 'application/json' },
  });
  return res.data;
};

export const deleteCustomer = async (cusNo) => {
  const res = await axios.delete(`${host}/order/sellercustomer`, { 
    data: { cusNo } 
  });
  return res.data;
};
