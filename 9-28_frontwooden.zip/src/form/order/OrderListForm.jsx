
import { useEffect } from "react";
import { OrderListArr } from "../../arrays/OrderListArrays";
import axios from "axios";
import { useCRUD } from "../../hook/useCRUD";
import { BASE_URL } from "../../api/PartOrderAPI";



const OrderListForm = ({children}) => {
 const {
  onSubmit,
  setItemList,
  setCustomerId,
  customerId,
  customer,
  setItemListId,
  itemList,
  orderQty,
  setOrderQty,
  onChange,
  setCustomer,
  
 }=useCRUD({
  keyField: "orderNo"
 });
  
  useEffect(()=> {
    console.log("요청 URL:", BASE_URL);
    axios.get(`${BASE_URL}/order/sellercustomer`).then(res => {
      const options = res.data.map(temp => ({ label: temp.cusComp, value: temp.cusNo}));
      setCustomer(options);
    });
    axios.get(`${BASE_URL}/plan/itemlist`)
      .then(res => {
        setItemList(res.data);  // 서버에서 받은 데이터 상태에 저장
        console.log("상품 리스트 받아옴:", res.data);  // 디버깅용
      })
      .catch(err => {
        console.error("상품 리스트 로딩 실패:", err);
      });
  },[])

 


  return (
    <div className="form-wrapper">
      <form onSubmit={onSubmit}>
        <label>거래처</label>
        <select onChange={(e) => {
    setCustomerId(e.target.value ? Number(e.target.value) : null);}} required
          value={customerId ?? ""}>
          <option value="" disabled>거래처를 선택하세요</option>
          { customer.map(option => ( 
            <option key={option.value} value={option.value}>{option.label}</option>
          ))};
        </select>
        <label>상품</label>
        <select onChange={(e) => setItemListId(Number(e.target.value))} required>
          <option value="" disabled>상품을 선택하세요</option>
          { itemList.map(option => (
            <option key={option.value} value={option.value}>{option.label}</option>
          ))}
        </select>
        <label>수량</label>
        <input type="number" min="1" value={orderQty} onChange={e => setOrderQty(Number(e.target.value))} required/>
        {
          OrderListArr.slice(3).map(data => (
            <p key={data.id}>
              <span className="form-child">{data.content}</span>
              <input type="text"  onChange={onChange}/>
            </p>
          ))
        }
        
        {children}
      </form>
    </div>
  );
};

export default OrderListForm;
