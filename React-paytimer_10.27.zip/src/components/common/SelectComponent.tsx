import React, { JSX } from "react";

type ListType = {
  id:number | string;
  text:string | string[];
  name:string;
  type?: string;
}
type SelectedTypes = {
  children? : React.ReactNode;
  handleChange? : React.ChangeEventHandler<HTMLInputElement | 
  HTMLSelectElement | 
  HTMLTextAreaElement>;
  add? : Record<string, string>,
  list:ListType,
}
export default function SelectComponent({children,handleChange,add,list}:SelectedTypes):JSX.Element{
  

  return(
    <>
      <select
      name={list.name}
      onChange={handleChange}
      value={add?.[list.name] || ""}
      >
        {children}
      </select>
    </>
  )
}