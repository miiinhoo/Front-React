import { JSX, useState } from "react";
import { AddPageArrays } from "../arrays/AddPageArrays";
import SelectComponent from "../components/common/SelectComponent";
import useEvent from "../hooks/useEvent";

function AddPage(): JSX.Element {
  const { 
    temp:add,
    bool:openOption,
    setBool:setOpenOption,
    handleChange,
    doNotRefreshSite
  } = useEvent();

  // ✅ 현재 선택된 항목
  const [ selectedItem, setSelectedItem ] = useState<string>("선택하세요..");

  return (
    <div className="page-wrapper">
      <div className="page-inner">
        <div className="page-content">
          <form>
            <h2>등록페이지</h2>
            {
              AddPageArrays.map(list => (
                <label key={list.id}>
                  {list.type === "dropdown" ? (
                    <>
                      <div className="outerSelectItem" onClick={() => setOpenOption(prev => !prev)}>
                        <div className="selectLists">
                          {/* 현재 선택된 텍스트 */}
                          <p className="selectedText">{selectedItem}</p>

                          {/* 드롭다운 옵션 */}
                          {openOption && list.outerSelect?.map((temp,inx) => (
                            <p 
                              key={inx}
                              onClick={(e) => {
                                doNotRefreshSite(e);
                                setSelectedItem(temp.name); // 선택한 텍스트 저장
                                setOpenOption(false);
                              }}
                            >
                              {temp.name}
                            </p>
                          ))}
                        </div>
                      </div>

                      {selectedItem === "할부방식" && (
                        <div className="installment-box a">
                          <p>💳 할부방식을 선택했습니다!</p>
                          <p>아래에서 세부 옵션을 선택하세요.</p>
                        </div>
                      )}

                      {selectedItem === "정기결제" && (
                        <div className="subscription-box b">
                          <p>🔁 정기결제를 선택했습니다!</p>
                          <p>구독 서비스 목록을 아래에서 선택하세요.</p>
                        </div>
                      )}
                    </>
                  ) : list.type === "select" ? (
                    <SelectComponent handleChange={handleChange} add={add} list={list}>
                      {list.options?.map((opt,inx) => (
                        <option key={inx} value={opt}>{opt}</option>
                      ))}
                    </SelectComponent>
                  ) : (
                    <input
                      type={list.type ?? "text"}
                      value={add[list.name] || ""}
                      name={list.name}
                      placeholder={list.text}
                      onChange={handleChange}
                    />
                  )}
                </label>
              ))
            }
          </form>
        </div>
      </div>
    </div>
  );
}

export default AddPage;
