import { JSX } from "react";

function StatPage():JSX.Element{
  return(
    <div className="page-wrapper">
      <div className="page-inner">
        <div className="page-content">
          
        </div>
      </div>
    </div>
  )
}
export default StatPage;