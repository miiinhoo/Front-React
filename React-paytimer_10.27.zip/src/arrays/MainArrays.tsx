export const MainArrays = [
  {
    id : 1, name : "리스트", pathname: "/list", emoji:"📋"
  },
  {
    id : 2, name : "등록", pathname: "/add", emoji:"➕"
  },
  {
    id : 3, name : "통계", pathname: "/stats", emoji:"📊"
  },
  {
    id : 4, name : "설정", pathname: "/setting", emoji:"⚙️"
  },
]