
export const FormDataArrays = [
  {
    addPage:{
      table : "",
      amount: "",
      payDate: "",
      method: "",
      cycle: "매월",
      memo: "",
    }
  }
]