package com.springboot.wooden.service;

import com.springboot.wooden.domain.Buyer;
import com.springboot.wooden.domain.Part;
import com.springboot.wooden.domain.PartOrder;
import com.springboot.wooden.dto.PartOrderRequestDto;
import com.springboot.wooden.dto.PartOrderResponseDto;
import com.springboot.wooden.repository.BuyerRepository;
import com.springboot.wooden.repository.PartOrderRepository;
import com.springboot.wooden.repository.PartRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Log4j2
@Transactional
public class PartOrderServiceImpl implements PartOrderService {

    private final PartOrderRepository partOrderRepository;
    private final BuyerRepository buyerRepository;
    private final PartRepository partRepository;
    private final ModelMapper modelMapper;

    // 전체 조회
    @Override
    @Transactional(readOnly = true)
    public List<PartOrderResponseDto> getAllPartOrders() {
        List<PartOrder> orders = partOrderRepository.findAll(Sort.by(Sort.Direction.DESC, "poNo"));

        return orders.stream()
                .map(order -> {
                    PartOrderResponseDto dto = modelMapper.map(order, PartOrderResponseDto.class);
                    dto.setBuyerComp(order.getBuyer() != null ? order.getBuyer().getBuyerComp() : null);
                    dto.setPartName(order.getPart() != null ? order.getPart().getPartName() : null);
                    return dto;
                })
                .toList();
    }

    // 단건 조회
    @Override
    @Transactional(readOnly = true)
    public PartOrderResponseDto getOne(Long poNo) {
        PartOrder order = partOrderRepository.findById(poNo)
                .orElseThrow(() -> new IllegalArgumentException("PartOrder not found: " + poNo));

        PartOrderResponseDto dto = modelMapper.map(order, PartOrderResponseDto.class);
        dto.setBuyerComp(order.getBuyer() != null ? order.getBuyer().getBuyerComp() : null);
        dto.setPartName(order.getPart() != null ? order.getPart().getPartName() : null);
        return dto;
    }

    // Buyer 기준 조회
    @Override
    @Transactional(readOnly = true)
    public List<PartOrderResponseDto> getByBuyerNo(Long buyerNo) {
        List<PartOrder> orders = partOrderRepository.findByBuyerBuyerNo(buyerNo);

        return orders.stream()
                .map(order -> {
                    PartOrderResponseDto dto = modelMapper.map(order, PartOrderResponseDto.class);
                    dto.setBuyerComp(order.getBuyer() != null ? order.getBuyer().getBuyerComp() : null);
                    dto.setPartName(order.getPart() != null ? order.getPart().getPartName() : null);
                    return dto;
                })
                .toList();
    }

    // 발주 등록
    @Override
    public Long addPartOrder(PartOrderRequestDto dto) {
        Buyer buyer = buyerRepository.findById(dto.getBuyerNo())
                .orElseThrow(() -> new IllegalArgumentException("Buyer not found: " + dto.getBuyerNo()));
        Part part = partRepository.findById(dto.getPartNo())
                .orElseThrow(() -> new IllegalArgumentException("Part not found: " + dto.getPartNo()));

        PartOrder order = modelMapper.map(dto, PartOrder.class);
        order.changeBuyer(buyer);
        order.changePart(part);

        return partOrderRepository.save(order).getPoNo();
    }

    // 발주 수정
    @Override
    public void updatePartOrder(Long poNo, PartOrderRequestDto dto) {
        PartOrder order = partOrderRepository.findById(poNo)
                .orElseThrow(() -> new IllegalArgumentException("PartOrder not found: " + poNo));

        Buyer buyer = buyerRepository.findById(dto.getBuyerNo())
                .orElseThrow(() -> new IllegalArgumentException("Buyer not found: " + dto.getBuyerNo()));
        Part part = partRepository.findById(dto.getPartNo())
                .orElseThrow(() -> new IllegalArgumentException("Part not found: " + dto.getPartNo()));

        modelMapper.map(dto, order);  // DTO -> Entity 매핑
        order.changeBuyer(buyer);
        order.changePart(part);
    }

    // 발주 삭제
    @Override
    public void deletePartOrder(Long poNo) {
        if (!partOrderRepository.existsById(poNo)) {
            throw new IllegalArgumentException("PartOrder not found: " + poNo);
        }
        partOrderRepository.deleteById(poNo);
    }
}
