package com.springboot.wooden.controller;

import com.springboot.wooden.dto.PartOrderRequestDto;
import com.springboot.wooden.dto.PartOrderResponseDto;
import com.springboot.wooden.service.PartOrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/buyer/partorder")  // 하이픈 제거, 카멜케이스
@RequiredArgsConstructor
public class PartOrderController {

    private final PartOrderService partOrderService;

    // 전체 발주 조회
    @GetMapping
    public ResponseEntity<List<PartOrderResponseDto>> getAllPartOrders() {
        List<PartOrderResponseDto> orders = partOrderService.getAllPartOrders();
        return ResponseEntity.ok(orders);
    }

//    // 단건 발주 조회
//    @GetMapping("/{poNo}")
//    public ResponseEntity<PartOrderResponseDto> getOne(@PathVariable Long poNo) {
//        PartOrderResponseDto order = partOrderService.getOne(poNo);
//        return ResponseEntity.ok(order);
//    }

//    // Buyer 기준 발주 조회
//    @GetMapping("/buyer/{buyerNo}")
//    public ResponseEntity<List<PartOrderResponseDto>> getByBuyer(@PathVariable Long buyerNo) {
//        List<PartOrderResponseDto> orders = partOrderService.getByBuyerNo(buyerNo);
//        return ResponseEntity.ok(orders);
//    }

    // 발주 등록
    @PostMapping
    public ResponseEntity<Long> addPartOrder(@RequestBody @Valid PartOrderRequestDto dto) {
        Long poNo = partOrderService.addPartOrder(dto);
        return ResponseEntity.ok(poNo);
    }

    // 발주 수정
    @PutMapping
    public ResponseEntity<Void> updatePartOrder(
            @RequestBody @Valid  PartOrderRequestDto dto
    ) {
        Long id = dto.getPoNo();
        partOrderService.updatePartOrder(id, dto);
        return ResponseEntity.ok().build();
    }

    // 발주 삭제
    @DeleteMapping
    public ResponseEntity<Void> deletePartOrder(@RequestBody PartOrderRequestDto dto) {
        Long id = dto.getPoNo();
        partOrderService.deletePartOrder(id);
        return ResponseEntity.noContent().build();
    }
}
