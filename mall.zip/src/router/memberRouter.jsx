import { Suspense,lazy } from "react";


const MemberRouter = () => {

  const Loading = <div>Loading...</div>;
  const LoginPage = lazy(() => import("../pages/member/LoginPage"));
  const LogoutPage = lazy(() => import("../pages/member/LogoutPage"));
  const KakaoRedirect = lazy(() => import("../pages/member/KakaoRedirectPage"))

  return[
    {
      path:'login',
      element: <Suspense fallback={Loading}><LoginPage/></Suspense>
    },
    {
      path: 'logout',
      element: <Suspense fallback={Loading}><LogoutPage/></Suspense>
    },
    {
      path: 'kakao',
      element: <Suspense fallback={Loading}><KakaoRedirect/></Suspense>
    }
  ];
}
export default MemberRouter;
