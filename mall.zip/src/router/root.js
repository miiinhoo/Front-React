import { lazy, Suspense } from "react";
import todoRouter from "./todoRouter";
import productRouter from "./productRouter";
import MemberRouter from "./memberRouter";

const { createBrowserRouter } = require("react-router-dom");

const Loading = <div>Loding</div>
const Main = lazy(() => import ("../pages/MainPage"))
const About = lazy(() => import ("../pages/AboutPage"))
const TodoIndex = lazy(() => import('../pages/todo/IndexPage'))

const ProductsIndex = lazy(() => import("../pages/products/IndexPage"))



const root = createBrowserRouter([
  
  {
    path: "",
    element: <Suspense fallback={Loading}><Main/></Suspense>
  },

  {
    path: "about",
    element: <Suspense fallback={Loading}><About/></Suspense>
  },
  {
    path: "todo",
    element: <Suspense fallback={Loading}><TodoIndex/></Suspense>,
    children: todoRouter()
  },
  {
    path: "products",
    element: <Suspense fallback={Loading}><ProductsIndex/></Suspense>,
    children: productRouter()
  },
  {
    path: 'member',
    children: MemberRouter()
  }
])

export default root;