import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { loginPost } from '../api/memberApi';
import { getCookie,setCookie,removeCookie } from '../util/cookieUtil';
// import { addAccessToken } from './jwtSlice';

const initState = {
    email: null,
    accessToken: null,
    nickname: null,
    roleNames: []
};

const loadMemberCookie = () => {
  const memberInfo = getCookie("member");
  // 닉네임 처리
  if(memberInfo && memberInfo.nickname)
    memberInfo.nickname = decodeURIComponent(memberInfo.nickname);
  return memberInfo;
}

export const loginPostAsync = createAsyncThunk('loginPostAsync', async (param, { dispatch }) => {
    try {
        const response = await loginPost(param);
        // access Token을 별도 slice에 저장하는 로직
        // dispatch(addAccessToken(response.accessToken)); 
        return response;
    } catch (error) {
        return { error: '로그인 실패. 서버를 확인하세요.' };
    }
});

const loginSlice = createSlice({
    name: 'LoginSlice',
    initialState: loadMemberCookie() || initState,
    reducers: {
        logout: (state) => {
            console.log("로그아웃...");
            removeCookie("member")
            return { ...initState };
        }
    },
    extraReducers: (builder) => {
        builder.addCase(loginPostAsync.fulfilled, (state, action) => {
            const payload = action.payload;

            // 정상적인 로그인 시에만 저장
            if(!payload.error)
              console.log(" 쿠키 저장 ")
              setCookie("member", JSON.stringify(payload), 1); // 1일


            if (payload.email) {
                console.log("로그인 성공! 상태 업데이트.");
                // immer를 사용하므로 state를 직접 수정해도 됩니다.
                state.email = payload.email;
                state.accessToken = payload.accessToken;
                state.nickname = payload.nickname;
                state.roleNames = payload.roleNames;
            } else {
                console.log("로그인 실패! 상태 초기화.");
                // 로그인 실패 시 상태를 초기 상태로 되돌립니다.
                state.email = null;
                state.accessToken = null;
                state.nickname = null;
                state.roleNames = [];
            }
        })
        .addCase(loginPostAsync.pending, (state, action) => {
            console.log("pending: 처리 중");
        })
        .addCase(loginPostAsync.rejected, (state, action) => {
            console.log("rejected: 오류");
            // 요청 자체가 실패하면 상태를 초기화합니다.
            state.email = null;
            state.accessToken = null;
            state.nickname = null;
            state.roleNames = [];
        });
    }
});

export const { logout } = loginSlice.actions;
export default loginSlice.reducer;