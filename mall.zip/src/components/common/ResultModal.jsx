const ResultModal = ({ title, content, callbackFn }) => {
  return (
    <div
      className="fixed top-0 left-0 z-[1055] flex h-full w-full justify-center items-start bg-black bg-opacity-20"
      onClick={() => {
        if (callbackFn) callbackFn()
      }}
    >
      <div
        className="relative bg-white shadow dark:bg-gray-700 w-1/4 rounded mt-10 mb-10 px-6 min-w-[600px]"
        onClick={(e) => e.stopPropagation()} // 모달 내부 클릭 시 닫히지 않도록
      >
        {/* 타이틀 */}
        <div className="justify-center bg-warning-400 mt-6 mb-6 text-2xl border-b-4 border-gray-500 text-center font-bold">
          {title}
        </div>

        {/* 내용 */}
        <div className="text-4xl border-orange-400 border-b-4 pt-4 pb-4 text-center">
          {content}
        </div>

        {/* 닫기 버튼 */}
        <div className="justify-end flex mt-4">
          <button
            className="rounded bg-blue-500 px-6 pt-4 pb-4 text-lg text-white"
            onClick={() => {
              if (callbackFn) callbackFn()
            }}
          >
            Close Modal
          </button>
        </div>
      </div>
    </div>
  )
}

export default ResultModal;
