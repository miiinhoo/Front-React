import { CSSTransition, SwitchTransition } from "react-transition-group";
import { RouterProvider,Routes, Route, useLocation } from 'react-router-dom';
import './App.css';
import root from './router/root';

function App() {
  return (
   <RouterProvider router={root}/>
  );
}

export default App;
