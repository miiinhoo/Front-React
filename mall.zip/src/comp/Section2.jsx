import React from 'react';

const Section2 = () => {
  return (
    <div className="section">
      <h1>Section 2</h1>
      <p>두 번째 페이지입니다.</p>
    </div>
  );
};

export default Section2;