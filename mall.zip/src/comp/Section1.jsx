import React from 'react';

const Section1 = () => {
  return (
    <div className="section">
      <h1>Section 1</h1>
      <p>첫 번째 페이지입니다.</p>
    </div>
  );
};

export default Section1;