import React from 'react';

const Section4 = () => {
  return (
    <div className="section">
      <h1>Section 4</h1>
      <p>네 번째 페이지입니다.</p>
    </div>
  );
};

export default Section4;