import React from 'react';

const Section3 = () => {
  return (
    <div className="section">
      <h1>Section 3</h1>
      <p>세 번째 페이지입니다.</p>
    </div>
  );
};

export default Section3;