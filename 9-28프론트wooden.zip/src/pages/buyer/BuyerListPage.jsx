
const BuyerListPage = () => {

    return(
        <>
            <h1>구매거래처</h1>
        </>
    )
}
export default BuyerListPage;