
const OrderApprovePage = () => {

    return(
        <div>
            <h2>
                주문완료현황
            </h2>
        </div>
    )
}
export default OrderApprovePage;