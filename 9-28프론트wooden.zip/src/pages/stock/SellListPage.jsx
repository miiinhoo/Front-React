
const SellListPage = () => {
  return (
    <div>
      <h2>실제판매수량</h2>
    </div>
  )
}
export default SellListPage;