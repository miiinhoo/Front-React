
import React from "react";
import { RouterProvider } from "react-router-dom";
import root from "./router/root";
import CustomCursor from "./components/CustomCursor";

function App() {
  return (
    <div className="MAIN_WRAPPER">
      <CustomCursor/>
      <RouterProvider router={root} />
    </div>
  );
}

export default App;
