import axios from "axios";

export const BASE_URL = "http://localhost:8080/api";

// 전체 주문 조회
export const getPartOrders = async () => {
    const res = await axios.get(`${BASE_URL}/buyer/partorder`);
    // console.log("API 응답:", response.data);
    return res.data;
};



export const createPartOrder = async (formData) => {
  const res = await axios.post(`${BASE_URL}/buyer/partorder`, formData, {
    headers: {
      'Content-Type': 'application/json',
    },
  });
  return res.data;
};

// 단건 수정
export const updatePartOrder = async (formData) => {
  const res = await axios.put(`${BASE_URL}/buyer/partorder`, formData, {
    headers: { 'Content-Type': 'application/json' },
  });
  return res.data;
};

export const deletePartOrder = async (poNo) => {
  const res = await axios.delete(`${BASE_URL}/buyer/partorder`, { 
    data: { poNo } 
  });
  return res.data;
};
