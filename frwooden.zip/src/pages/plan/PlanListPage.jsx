

const PlanListPage = () => {
  
  return(
    <div>
      <h2>생산리스트</h2>
    </div>
  );
}
export default PlanListPage;