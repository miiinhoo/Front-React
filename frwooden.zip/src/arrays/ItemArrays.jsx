export const ItemListArrays = [            
  { id: 1, clmn: "itemNo", input: "number",content: "일련번호" },
  { id: 2, clmn: "itemCode", input: "text", content: "상품코드" },
  { id: 3, clmn: "itemName", input: "text", content: "상품명" },
  { id: 4, clmn: "itemSpec", input: "text", content: "상품규격" },
  { id: 5, clmn: "itemPrice", input: "number", content: "상품단가" },
];