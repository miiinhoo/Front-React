// src/test/java/com/springboot/wooden/repository/OrderRepositoryTest.java
package com.springboot.wooden.repository;

import com.springboot.wooden.domain.Customer;
import com.springboot.wooden.domain.Item;
import com.springboot.wooden.domain.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class OrderRepositoryTest {

    @Autowired OrderRepository orderRepository;
    @Autowired CustomerRepository customerRepository;
    @Autowired ItemRepository itemRepository;

    @Test
    void createOrder() {
        Long cusNo = 3L;
        Long itemNo = 5L;

        // 존재 확인 (인스턴스 메서드)
        assertThat(customerRepository.existsById(cusNo)).isTrue();
        assertThat(itemRepository.existsById(itemNo)).isTrue();

        // FK만 꽂기: SELECT 없이 프록시 참조
        Customer cRef = customerRepository.getReferenceById(cusNo);
        Item iRef = itemRepository.getReferenceById(itemNo);

        Order order = Order.builder()
                .customer(cRef)          // ★ FK 세팅
                .item(iRef)              // ★ FK 세팅
                .orderQty(7)
                .orderPrice(12000)
                .orderState("주문")
                .orderDeliState("대기")
                .orderDate(LocalDate.now())
                .cusAddr("서울시 강남구")
                .build();

        Order saved = orderRepository.save(order);
        assertThat(saved.getOrderNo()).isNotNull();
        System.out.println("orderNo = " + saved.getOrderNo());
    }
}
