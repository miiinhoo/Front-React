import { JSX } from "react";


export default function ThirdSection():JSX.Element{
  return(
    <div className="section-inner">
    
    </div>
  )
}