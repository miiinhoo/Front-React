import { JSX } from "react";

export default function SecondSection():JSX.Element{
  return(
    <div className="section-inner">
      111
    </div>
  )
}