import { JSX } from "react";
import { AddPageArrays } from "../arrays/AddPageArrays";
import SelectComponent from "../components/common/SelectComponent";
import useEvent from "../hooks/useEvent";

function AddPage():JSX.Element{
  const { 
    temp:add,
    handleChange 
  } = useEvent();
  return(
    <div className="page-wrapper">
      <div className="page-inner">
        <div className="page-content">
          <form>
            <h2>등록페이지</h2>
            {
              AddPageArrays.map(list => (
                <label key={list.id}>
                  {list.name === "method" ?
                    <SelectComponent 
                    handleChange={handleChange}
                    add={add}
                    list={list}
                    >
                      <option value="">11</option>
                      <option value="">22</option>
                      <option value="">11</option>
                    </SelectComponent>  
                    :""
                  }
                  <input type={list.type ?? "text"}
                  value={add[list.name] || ""}
                  name={list.name}
                  onChange={handleChange}
                  />
                </label>
              ))
            }
          </form>
        </div>
      </div>
    </div>
  )
}
export default AddPage;