import React, { JSX, useEffect } from "react";

type ListType = {
  id:number | string,
  text:string | string[],
  name:string,
  type?: string;
}
type SelectedTypes = {
  children? : React.ReactElement<HTMLSelectElement>
  | React.ReactElement<HTMLSelectElement>[],
  handleChange? : React.ChangeEventHandler<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>,
  add? : Record<string, string | string[]>,
  list:ListType,
}
export default function SelectComponent({children,handleChange,add,list}:SelectedTypes):JSX.Element{
  
  useEffect(() => {
    console.log("변경 값 : ", handleChange)
  },[handleChange])

  return(
    <>
      <select
      onChange={handleChange}
      value={add?.[list.name] || ""}
      >
        {children}
      </select>
    </>
  )
}