import React, { JSX } from "react";

type Props = {
  text: string,
  classN?: string,
  click: () => void,
  types? : "submit" | "button" | "reset",
  openModal?: React.SetStateAction<boolean>,
}

export default function ButtonComponent({text,click,types,classN,openModal}:Props):JSX.Element{

  return(
    <>
      <button 
      onClick={click}
      type={types ?? "button"}
      className={`${classN ?? ""}${openModal ? " open":""}`}>
        { text }
      </button>
    </>
  );
}