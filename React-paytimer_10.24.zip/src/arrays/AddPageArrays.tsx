export const AddPageArrays = [
  { id: 1, text:"종류" , name:"title"},
  { id: 2, text:"수량" , name:"amount", type:"number"},
  { id: 3, text:"날짜" , name:"payDate", type:"date"},
  { id: 4, text:"결제방법" , name:"method"},
  { id: 5, text:"개월수" , name:"cycle"},
  { id: 6, text:"요금제" , name:"memo"},
]