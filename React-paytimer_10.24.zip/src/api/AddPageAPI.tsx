import axios from "axios";

const API_URL = "https://us-central1-paytimer-61bd8.cloudfunctions.net/api/api/payments";

export const createPayment = async (data:any) => {
  const res = await axios.post(API_URL, data);
  return res.data;
};

export const getPayments = async () => {
  const res = await axios.get(API_URL);
  return res.data;
};
