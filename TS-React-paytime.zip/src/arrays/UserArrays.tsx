export const UserArrays = [
    { id: 1, text: "아이디",name: "email" },
    { id: 2, text: "비밀번호", name: "password" },
  ];
