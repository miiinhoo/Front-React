import { JSX } from "react";
import useFireBase from "../../hooks/useFireBase";
import { UserArrays } from "../../arrays/UserArrays";
import useEvent from "../../hooks/useEvent";
import ButtonComponent from "../ButtonComponent";

export default function LoginComponent():JSX.Element{

  const { tryLogin } = useFireBase();
  const { 
    temp:change,
    setTemp:setChange,
    handleChange 
  } = useEvent();

  return(
    <div className="login-form">
      <form>
        {UserArrays.map((list,index)=> (
          <label key={index}>
            <span>{list.text}</span>
            <input type={list.name} 
            name={list.name}
            value={change?.[list.name] ?? []}
            onChange={handleChange}
            />
          </label>
        ))}
        <ButtonComponent
        text="로그인하기"
        types="submit"
        click={() => tryLogin(change.email, change.password)}
        classN="login"
        />
      </form>
    </div>
  );
}