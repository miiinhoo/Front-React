import { useState } from "react";
import { UserLogin,UserSignup } from "../api/FireBaseAPI";

export default function useFireBase() {
  const [ user,setUser ] = useState<any>(null);
  const [ loading, setLoading ] = useState(false);
  const [ error, setError ] = useState<string | null>(null);

  
  const tryLogin = async(email:string,password:string) => {
    try{
        
      setLoading(true);
      const res = await UserLogin(email,password);
      setUser(res.user);
      console.log("로그인 성공")
    }catch (err: any) {
      if (err.code === "auth/user-not-found") alert("해당 이메일의 계정이 없습니다.");
      else if (err.code === "auth/wrong-password") alert("비밀번호가 잘못되었습니다.");
      else alert("로그인 실패: " + err.message);
      setError(err.message);
    }
    finally{
      setLoading(false);
    }
  }
  const trySignup = async(email:string,password:string) => {
    try{
      if(!email || !email.includes("@")){
        alert("올바른 이메일 형식이 아님")
        return;
      }
      if(!password || password.length < 6){
        alert("비밀번호는 6자 이상이여야 함.")
        return;
      }
      setLoading(true);
      const res = await UserSignup(email,password);
      setUser(res.user);
      console.log("회원가입 성공")
    }catch(err:any){
      console.error(err);
      setError(err)
    }finally{
      setLoading(false);
    }
  }

  return { user,loading,error,tryLogin,trySignup };
}