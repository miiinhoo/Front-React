import { UserCredential, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from "firebase/auth";
import { auth } from "../firebase";


export const UserSignup = async (email:string, password:string):Promise<UserCredential> => {
  const res = await createUserWithEmailAndPassword(auth, email, password);
  return res;
};

export const UserLogin = async (email:string ,password:string):Promise<UserCredential> => {
  const res = await signInWithEmailAndPassword(auth, email, password);
  return res;
};
// 로그아웃
export const firebaseLogout = async () => {
  return await signOut(auth);
};