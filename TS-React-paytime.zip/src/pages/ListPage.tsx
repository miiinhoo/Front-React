
import { JSX } from "react";

function ListPage():JSX.Element{
  return(
    <div className="page-wrapper">
      ListPage입니다.
    </div>
  )
}
export default ListPage;
