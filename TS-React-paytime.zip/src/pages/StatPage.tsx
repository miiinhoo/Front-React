import { JSX } from "react";

function StatPage():JSX.Element{
  return(
    <div className="page-wrapper">
      Stat페이지 입니다..
    </div>
  )
}
export default StatPage;