import { JSX } from "react";


function AddPage():JSX.Element{
  return(
    <div className="page-wrapper">
      Add페이지 입니다..
    </div>
  )
}
export default AddPage;