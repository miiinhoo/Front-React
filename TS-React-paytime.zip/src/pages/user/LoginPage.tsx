import React, { JSX } from "react";
import ButtonComponent from "../../components/ButtonComponent";
import LoginComponent from "../../components/user/LoginComponent";
import useEvent from "../../hooks/useEvent";

export default function LoginPage():JSX.Element{
  const { navigate } = useEvent();

  return(
    <div className="page-wrapper">
      LoginPage 테스트
      <React.Fragment>
          <LoginComponent/>
      </React.Fragment>
      
      <ButtonComponent text={"회원가입창으로"} click={() => navigate("/user/signup")} classN="join"/>
    </div>
  );
}