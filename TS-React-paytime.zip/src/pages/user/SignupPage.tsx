import { JSX, useEffect, useState } from "react";
import useFireBase from "../../hooks/useFireBase";
import { UserArrays } from "../../arrays/UserArrays";
import ButtonComponent from "../../components/ButtonComponent";
import useEvent from "../../hooks/useEvent";

export default function JoinPage():JSX.Element{
  const { trySignup,user } = useFireBase();

  const { 
    temp:change,
    setTemp:setChange,
    handleChange, 
    navigate,
  } = useEvent();
  useEffect(() => {
    console.log(change);
  },[]);
  const handleUserInfo = () => {
    if( !change.email || !change.password ) {
      alert("아이디 또는 비밀번호가 빈칸.")
      return;
    }
    trySignup(change.email,change.password);
    setChange({email:"",password:""});
  }
  return(
    <div className="page-wrapper">
      <h2>firebase 회원가입 테스트</h2>
      <form>
        {UserArrays.map((list,index) => (
          <label key={index}>
            <span>{list.text}</span>
            <input type={list.name} 
            name={list.name}
            value={change?.[list.name] ?? []}
            onChange={handleChange}/>
          </label>
        ))}
        <div className="button-wrapper">
        <ButtonComponent 
          text="가입" 
          types="submit" 
          click={handleUserInfo}
          classN="join"
          />
          <ButtonComponent
          text="로그인창으로"
          types="button"
          click={() => navigate("/user/login")}
          classN="login"
          />
        </div>
      </form>
    </div>
  )
}