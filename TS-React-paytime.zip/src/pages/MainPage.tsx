import { JSX } from "react";

function MainPage():JSX.Element{

  return(
    <div className="page-wrapper">
      main
    </div>
  );
};
export default MainPage;