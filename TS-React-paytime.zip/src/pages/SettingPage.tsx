import { JSX } from "react";

function SettingPage():JSX.Element{
  return(
    <div className="page-wrapper">
      설정 페이지 입니다..
    </div>
  )
}
export default SettingPage;