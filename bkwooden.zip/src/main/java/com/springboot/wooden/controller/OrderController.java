//package com.springboot.wooden.controller;
//
//import com.springboot.wooden.dto.OrderRequestDto;
//import com.springboot.wooden.dto.OrderResponseDto;
//import com.springboot.wooden.service.OrderService;
//import jakarta.validation.Valid;
//import lombok.RequiredArgsConstructor;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.io.Serial;
//import java.security.Provider;
//import java.util.List;
//
//@RestController // REST API 컨트롤러 (JSON 반환)
//@RequestMapping("/api/order")
//@RequiredArgsConstructor
//public class OrderController {
//
//    private final OrderService service;
//
//    // 전체 주문 조회
//    @GetMapping
//    public List<OrderResponseDto> getOrders() {
//        return service.getAllOrders();
//    }
//
//    // 주문 등록
//    @PostMapping
//    public ResponseEntity<OrderResponseDto> addOrder(@RequestBody @Valid OrderRequestDto dto) {
//        OrderResponseDto saved = service.save(dto);
//        return orderService.register(dto); // saveOrder → register
//    }
//
//    // 주문 수정
//    @PutMapping("/{orderNo}")
//    public OrderResponseDto updateOrder(
//            @PathVariable Long orderNo,
//            @RequestBody OrderRequestDto dto) {
//        return orderService.update(orderNo, dto);
//    }
//
//    // 주문 삭제
//    @DeleteMapping("/{orderNo}")
//    public void deleteOrder(@PathVariable Long orderNo) {
//        orderService.delete(orderNo);
//    }
//}
