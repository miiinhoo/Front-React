package com.springboot.wooden.service;

import com.springboot.wooden.dto.PartOrderRequestDto;
import com.springboot.wooden.dto.PartOrderResponseDto;

import java.util.List;

public interface PartOrderService {

    Long addPartOrder(PartOrderRequestDto dto);            // 등록

    PartOrderResponseDto getOne(Long poNo);               // 단건 조회

    List<PartOrderResponseDto> getByBuyerNo(Long buyerNo); // Buyer 기준 조회

    void updatePartOrder(Long poNo, PartOrderRequestDto dto); // 수정

    void deletePartOrder(Long poNo);                      // 삭제

    List<PartOrderResponseDto> getAllPartOrders();        // 전체 조회
}
