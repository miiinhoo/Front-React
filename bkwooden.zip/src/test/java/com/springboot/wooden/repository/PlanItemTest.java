package com.springboot.wooden;

import com.springboot.wooden.domain.Item;
import com.springboot.wooden.domain.Plan;
import com.springboot.wooden.repository.ItemRepository;
import com.springboot.wooden.repository.PlanRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.Optional;

@SpringBootTest
public class PlanItemTest {

    @Autowired
    private PlanRepository planRepository;

    @Autowired
    private ItemRepository itemRepository;

    @Test
    void saveAndFetchPlanWithItem() {

//        // 1️⃣ Item 먼저 저장
//        Item item = Item.builder()
//                .itemCode("A001")
//                .itemName("상품A")
//                .itemSpec("규격A")      // 필드명 정확히
//                .itemPrice(1000)
//                .build();
//        itemRepository.save(item);
//
//        // 2️⃣ Plan 저장 (Item 참조)
//        Plan plan = Plan.builder()
//                .item(item)  // 반드시 DB에 저장된 Item 참조
//                .planQty(10)
//                .planState("READY")
//                .planStartDate(LocalDate.now())
//                .planEndDate(LocalDate.now().plusDays(7))
//                .build();
//        planRepository.save(plan);

//        // 3️⃣ DB에서 Plan 조회 및 Item 정보 확인
//        Optional<Plan> fetchedPlanOpt = planRepository.findById(plan.getPlanNo());
//        if(fetchedPlanOpt.isPresent()) {
//            Plan fetchedPlan = fetchedPlanOpt.get();
//            System.out.println("Plan No: " + fetchedPlan.getPlanNo());
//            System.out.println("Plan Qty: " + fetchedPlan.getPlanQty());
//            System.out.println("Plan State: " + fetchedPlan.getPlanState());
//            System.out.println("Item Name: " + fetchedPlan.getItem().getItemName());
//            System.out.println("Item Spec: " + fetchedPlan.getItem().getItemSpec());
//            System.out.println("Item Price: " + fetchedPlan.getItem().getItemPrice());
//        } else {
//            System.out.println("Plan 조회 실패");
//        }

       
    }
}
