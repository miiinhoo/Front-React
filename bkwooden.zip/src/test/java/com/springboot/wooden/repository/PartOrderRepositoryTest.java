// src/test/java/com/springboot/wooden/repository/PartOrderRepositoryTest.java
package com.springboot.wooden.repository;

import com.springboot.wooden.domain.Buyer;
import com.springboot.wooden.domain.Part;
import com.springboot.wooden.domain.PartOrder;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@SpringBootTest
@Log4j2
public class PartOrderRepositoryTest {

    @Autowired
    private PartOrderRepository partOrderRepository;

    @Autowired
    private BuyerRepository buyerRepository;

    @Autowired
    private PartRepository partRepository;

    @Test
    public void testInsert() {
        // Buyer와 Part 먼저 생성
        Buyer buyer = Buyer.builder()
                .buyerComp("테스트구매처")
                .buyerName("담당자A")
                .buyerEmail("test@naver.com")
                .buyerPhone("01011112222")
                .buyerAddr("서울시")
                .build();
        buyerRepository.save(buyer);

        Part part = Part.builder()
                .buyer(buyer)
                .partCode("P001")
                .partName("부품A")
                .partSpec("규격A")
                .partPrice(1000)
                .build();
        partRepository.save(part);

        // PartOrder 등록
        PartOrder order = PartOrder.builder()
                .buyer(buyer)
                .part(part)
                .poQty(5)
                .poPrice(5000)
                .poState("발주")
                .poDate(LocalDate.now())
                .buyerAddr("서울시 강남구")
                .build();
        partOrderRepository.save(order);

        log.info("INSERT => {}", order);
    }

    @Test
    public void testRead() {
        Long poNo = 1L;
        Optional<PartOrder> result = partOrderRepository.findById(poNo);
        PartOrder order = result.orElseThrow();
        log.info("READ => {}", order);
    }

    @Test
    public void testModify() {
        Long poNo = 1L;
        PartOrder order = partOrderRepository.findById(poNo).orElseThrow();

        order.changePoQty(10);
        order.changePoPrice(10000);
        order.changePoState("확정");
        order.changeBuyerAddr("서울시 서초구");

        partOrderRepository.save(order);
        log.info("MODIFY => {}", order);
    }

    @Test
    public void testDelete() {
        Long poNo = 1L;
        partOrderRepository.deleteById(poNo);
        log.info("DELETE => poNo={}", poNo);
    }

    @Test
    public void testFindByBuyerNo() {
        Long buyerNo = 1L;
        List<PartOrder> orders = partOrderRepository.findByBuyerBuyerNo(buyerNo);
        orders.forEach(o -> log.info("BY BUYER => {}", o));
    }
}
